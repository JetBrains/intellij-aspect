"""Bazel-specific intellij aspect."""

load(
    ":intellij_info_impl_bundled.bzl",
    "intellij_info_aspect_impl",
    "is_valid_aspect_target",
    "make_intellij_info_aspect",
)

EXTRA_DEPS = [
    "embed",  # From go rules (bazel only)
    "_cc_toolchain",  # From rules_cc (bazel only)
]

TOOLCHAIN_TYPE_DEPS = [
    "@@bazel_tools//tools/cpp:toolchain_type",  # For rules_cc
]

def get_py_launcher(target, ctx):
    """Returns the python launcher for a given rule."""

    # Used by other implementations of get_launcher
    _ = target  # @unused
    attr = ctx.rule.attr
    if hasattr(attr, "_launcher") and attr._launcher != None:
        return str(attr._launcher.label)
    return None

def _collect_targets_from_toolchains(ctx, toolchain_types):
    """Returns a list of targets for the given toolchain types."""
    result = []

    for toolchain_type in toolchain_types:
        # toolchains attribute only available in Bazel 8+
        toolchains = getattr(ctx.rule, "toolchains", [])

        if toolchain_type in toolchains:
            if is_valid_aspect_target(toolchains[toolchain_type]):
                result.append(toolchains[toolchain_type])

    return result

semantics = struct(
    toolchains_propagation = struct(
        toolchain_types = TOOLCHAIN_TYPE_DEPS,
        collect_toolchain_deps = _collect_targets_from_toolchains,
    ),
    extra_deps = EXTRA_DEPS,
    extra_required_aspect_providers = [],
    py = struct(
        get_launcher = get_py_launcher,
    ),
)

def _aspect_impl(target, ctx):
    return intellij_info_aspect_impl(target, ctx, semantics)

# TEMPLATE-INCLUDE-BEGIN
intellij_info_aspect = make_intellij_info_aspect(
    _aspect_impl,
    semantics,
    toolchains_aspects = TOOLCHAIN_TYPE_DEPS,
)
# TEMPLATE-INCLUDE-END

